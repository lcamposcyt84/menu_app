import { ConsortiumRegistration } from "@/components/consortium-registration"

export default function ConsortiumRegisterPage() {
  return <ConsortiumRegistration />
}
