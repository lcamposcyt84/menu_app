import { SuperAdminLogin } from "@/components/super-admin-login"

export default function AdminLoginPage() {
  return <SuperAdminLogin />
}
